
#include "StochasticFunctionMinimizationProblem.h"

namespace Grante {

StochasticFunctionMinimizationProblem::~StochasticFunctionMinimizationProblem()
{
}

}

