Temporary data produced by the test cases go in this directory.
