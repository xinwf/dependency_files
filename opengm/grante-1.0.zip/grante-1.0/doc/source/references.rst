
References
==========

.. [Kschischang2001] Frank R. Kschischang, Brendan J. Frey, and Hans-Andrea Loeliger,
	"Factor graphs and the sum-product algorithm",
	IEEE Transactions on Information Theory, Vol. 47, No. 2, pages 498-519, 2001.

.. [Lafferty2001] John Lafferty, Andrew McCallum, and Fernando Pereira,
	"Conditional Random Fields: Probabilistic Models for Segmenting and Labeling Sequence Data",
	ICML, 2001.

.. [Taskar2003] Ben Taskar, Carlos Guestrin, Vassil Chatalbashev, and Daphne Koller,
	"Max-Margin Markov Networks",
	JMLR, to appear, `PDF <http://robotics.stanford.edu/~koller/Papers/m3n-jmlr.pdf.gz>`_.

