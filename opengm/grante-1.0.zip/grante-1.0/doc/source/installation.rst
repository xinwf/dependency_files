
Installation Instructions
=========================

The distribution contains a file INSTALL.txt that describes how the library
can be installed on Windows and Unix systems.

