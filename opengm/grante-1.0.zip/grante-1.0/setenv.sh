#export PATH=/cygdrive/c/Users/senowozi/dev/mingw/mingw64/bin:$PATH
export PATH=/cygdrive/c/Users/senowozi/dev/mingw/mingw64_4.5.2/bin:$PATH
